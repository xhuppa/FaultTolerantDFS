package edu.gmu.cs475.internal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RunnerConfig {

	@SuppressWarnings("unused")
	@Autowired
	private Main main;
}
